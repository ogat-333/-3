@echo off
setlocal
cd /d "%~dp0"
where java >nul 2>nul || (echo Java не найден. Установите Android Studio с JDK и повторите. & pause & exit /b 1)
where gradle >nul 2>nul || (echo Gradle не найден в PATH. Откройте проект в Android Studio и выберите Build ^> Generate App Bundles or APKs ^> Generate APKs. & pause & exit /b 1)
gradle :app:assembleDebug
if errorlevel 1 (echo Сборка завершилась с ошибкой. & pause & exit /b 1)
echo.
echo APK готов: app\build\outputs\apk\debug\app-debug.apk
pause
