#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle не найден. Откройте проект в Android Studio и выберите Build > Generate App Bundles or APKs > Generate APKs."
  exit 1
fi
gradle :app:assembleDebug
echo "APK готов: app/build/outputs/apk/debug/app-debug.apk"
