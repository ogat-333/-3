ГЕРБАРИЙ БЕЗЫМЯННОГО — Android Episode I v1.0.0
ГОТОВЫЙ К СБОРКЕ ПРОЕКТ

Самый простой способ получить APK:

1. Установите Android Studio.
2. Распакуйте этот ZIP в любую папку.
3. В Android Studio выберите File → Open и укажите папку проекта.
4. Дождитесь окончания синхронизации Gradle.
5. Если Android Studio предложит установить Android SDK 35 — согласитесь.
6. Выберите Build → Generate App Bundles or APKs → Generate APKs.
7. После сборки нажмите "locate". APK будет здесь:
   app/build/outputs/apk/debug/app-debug.apk

Параметры:
- Application ID: com.gerbarij.bezymyannogo
- Название: Гербарий Безымянного
- Версия: 1.0.0
- Android минимум: 6.0 (API 23)
- Целевой SDK: 35
- Ориентация: портретная
- Интернет-разрешение НЕ требуется

Важно:
- Это debug APK, подходящий для установки на телефон и тестирования.
- Для Google Play позже понадобится release-сборка и подпись ключом.
- Проект использует WebView и локальные assets; интернет во время игры не нужен.

Автоматическая сборка:
- Windows: запустите BUILD_APK.bat, если Gradle доступен в PATH.
- macOS/Linux: ./BUILD_APK.sh, если Gradle доступен в PATH.

Если Gradle не установлен, Android Studio сама скачает/подключит совместимые компоненты при синхронизации проекта.

Cloud build: Codemagic can use codemagic.yaml in this project. The workflow builds the release APK artifact.
